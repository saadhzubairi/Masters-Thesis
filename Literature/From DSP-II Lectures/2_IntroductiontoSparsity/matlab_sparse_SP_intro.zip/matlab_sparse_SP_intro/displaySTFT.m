function displaySTFT(c, fs, T, dBlim)

% displaySTFT(c, fs, T, dBlim)
%
% DISPLAY STFT (short-time Fourier transform)
%
% INPUT
%   c     : STFT coefficient (2D array)
%   fs    : sampling rate (samples/second)
%   T     : signal duration (seconds)
%   dBlim : limits for colorbar in dB

% [Nf, Nt] = size(c);

% imagesc([0 T], [0 fs/2]/1e3, 20*log10(abs(c(1:Nf/2,:))))
imagesc([0 T], [0 fs]/1e3, 20*log10(abs(c)))
caxis(dBlim)
axis xy
ylabel('Frequency (kHz)')
xlabel('Time (seconds)')
ylim([0 fs/2]/1e3)          % Show just positive frequencies

cm = colormap( 'gray' );
cm = cm(end:-1:1,:);
colormap(cm);

CB = colorbar;
set(CB, 'ytick', (-50:10:0))

shg

